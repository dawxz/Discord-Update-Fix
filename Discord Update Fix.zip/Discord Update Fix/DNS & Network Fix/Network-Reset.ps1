Start-Process powershell -Verb RunAs -ArgumentList '-Command netsh int ip reset'
Write-Host "Network Settings Reset" -ForegroundColor Yellow
Pause