Start-Process powershell -Verb RunAs -ArgumentList '-Command netsh winsock reset'
Write-Host "You may need to restart your computer." -ForegroundColor Yellow
Pause