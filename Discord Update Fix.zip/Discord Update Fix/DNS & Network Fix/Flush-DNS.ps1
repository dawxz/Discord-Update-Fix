Start-Process powershell -Verb RunAs -ArgumentList '-Command ipconfig /flushdns'
Write-Host "DNS cache cleared." -ForegroundColor Green
Pause