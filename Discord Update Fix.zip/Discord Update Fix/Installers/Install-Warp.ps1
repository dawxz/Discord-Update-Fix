$ErrorActionPreference = "Stop"

$msiPath = Join-Path $env:TEMP "Cloudflare_WARP.msi"
$url     = "https://downloads.cloudflareclient.com/v1/download/windows/ga"

function Fail($message) {
    Write-Host ""
    Write-Host "[HATA] $message" -ForegroundColor Red
    Write-Host ""
    Pause
    exit 1
}

function Info($message) {
    Write-Host "[INFO] $message" -ForegroundColor Cyan
}

function Ok($message) {
    Write-Host "[OK] $message" -ForegroundColor Green
}

try {
    Info "Cloudflare WARP MSI indiriliyor..."
    Start-BitsTransfer -Source $url -Destination $msiPath

    if (!(Test-Path $msiPath)) {
        Fail "MSI dosyasi olusturulamadi."
    }

    $file = Get-Item $msiPath
    if ($file.Length -le 0) {
        Fail "MSI dosyasi 0 bayt indi."
    }

    Ok "Indirme tamamlandi. Boyut: $($file.Length) bayt"

    Info "Sessiz kurulum baslatiliyor..."
    $process = Start-Process "msiexec.exe" `
        -ArgumentList "/i `"$msiPath`" /qn /norestart" `
        -Verb RunAs `
        -Wait `
        -PassThru

    if ($process.ExitCode -ne 0) {
        Fail "Kurulum basarisiz oldu. Cikis kodu: $($process.ExitCode)"
    }

    Ok "WARP kurulumu tamamlandi."

    $warpExe1 = "C:\Program Files\Cloudflare\Cloudflare WARP\Cloudflare WARP.exe"
    $warpExe2 = "C:\Program Files\Cloudflare\Cloudflare One Agent\Cloudflare WARP.exe"

    if (Test-Path $warpExe1) {
        Info "WARP aciliyor..."
        Start-Process $warpExe1
        Ok "WARP baslatildi."
    }
    elseif (Test-Path $warpExe2) {
        Info "WARP aciliyor..."
        Start-Process $warpExe2
        Ok "WARP baslatildi."
    }
    else {
        Info "WARP kuruldu ama exe yolu otomatik bulunamadi."
    }

    if (Test-Path $msiPath) {
        Remove-Item $msiPath -Force -ErrorAction SilentlyContinue
        Info "Gecici MSI dosyasi temizlendi."
    }

    Write-Host ""
    Ok "Islem tamamlandi."
    Start-Sleep -Seconds 2
}
catch {
    Fail $_.Exception.Message
}