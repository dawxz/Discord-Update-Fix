$ErrorActionPreference = "Stop"

$zipUrl = "https://github.com/cagritaskn/GoodbyeDPI-Turkey/releases/download/release-0.2.3rc3-turkey/goodbyedpi-0.2.3rc3-turkey.zip"
$zipPath = Join-Path $env:TEMP "goodbyedpi-0.2.3rc3-turkey.zip"
$extractPath = Join-Path $env:TEMP "goodbyedpi-0.2.3rc3-turkey"

function Fail($message) {
    Write-Host ""
    Write-Host "[HATA] $message" -ForegroundColor Red
    Write-Host ""
    Pause
    exit 1
}

function Info($message) {
    Write-Host "[INFO] $message" -ForegroundColor Cyan
}

function Ok($message) {
    Write-Host "[OK] $message" -ForegroundColor Green
}

try {
    if (Test-Path $zipPath) {
        Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    }

    if (Test-Path $extractPath) {
        Remove-Item $extractPath -Recurse -Force -ErrorAction SilentlyContinue
    }

    Info "ZIP dosyasi indiriliyor..."
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath

    if (!(Test-Path $zipPath)) {
        Fail "ZIP dosyasi indirilemedi."
    }

    $file = Get-Item $zipPath
    if ($file.Length -le 0) {
        Fail "ZIP dosyasi 0 bayt indi."
    }

    Ok "Indirme tamamlandi. Boyut: $($file.Length) bayt"

    Info "ZIP aciliyor..."
    Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force

    if (!(Test-Path $extractPath)) {
        Fail "ZIP acilamadi."
    }

    Ok "ZIP basariyla acildi."
    Info "Klasor aciliyor..."
    Start-Process explorer.exe $extractPath

    Write-Host ""
    Ok "Islem tamamlandi."
    Pause
}
catch {
    Fail $_.Exception.Message
}