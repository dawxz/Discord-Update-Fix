$ErrorActionPreference = "Stop"

$downloadUrl = "https://discord.com/api/download?platform=win"
$installerPath = Join-Path $env:TEMP "DiscordSetup.exe"

function Info($msg){
    Write-Host "[INFO] $msg" -ForegroundColor Cyan
}

function Ok($msg){
    Write-Host "[OK] $msg" -ForegroundColor Green
}

function Fail($msg){
    Write-Host "[HATA] $msg" -ForegroundColor Red
    exit
}

try {

    if (Test-Path $installerPath) {
        Remove-Item $installerPath -Force -ErrorAction SilentlyContinue
    }

    Info "Discord indiriliyor..."

    Invoke-WebRequest -Uri $downloadUrl -OutFile $installerPath

    if (!(Test-Path $installerPath)) {
        Fail "Discord indirilemedi."
    }

    $file = Get-Item $installerPath
    if ($file.Length -le 0) {
        Fail "Indirilen dosya 0 bayt."
    }

    Ok "Indirme tamamlandi."

    Info "Discord kurulumu baslatiliyor..."

    Start-Process $installerPath -Wait

    Ok "Discord kurulumu tamamlandi."

    $discordPath = "$env:LOCALAPPDATA\Discord\Update.exe"

    if (Test-Path $discordPath) {
        Info "Discord aciliyor..."
        Start-Process $discordPath -ArgumentList "--processStart Discord.exe"
    }

    Ok "Islem tamamlandi."

}
catch {
    Fail $_.Exception.Message
}